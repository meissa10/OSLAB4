#ifndef UTIL_H
#define UTIL_H

#include "process.h"

/**
 * Utility function file
 */

Process *parse_file(FILE *);

#endif				// UTIL_H
